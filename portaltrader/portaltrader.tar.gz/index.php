<?php
$bannerInfo = 1;
$title = 'Portal Trader';
include "header.php";
?>
<!-- //banner -->

<!-- welcome -->
<div class="welcome">
	 <div class="container">
		 <div class="welcome-top">
			<h2 class="w3ls_head">Bem-Vindo</h2>
			
			 <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque
				corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</p>
		 </div>
		  <div class="charitys">
			  <div class="col-md-4 chrt_grid" style="visibility: visible; -webkit-animation-delay: 0.4s;">
				   <div class="chrty">
						<figure class="icon">
							 <span class="glyphicon-icon glyphicon-heart" aria-hidden="true"></span>
						</figure>
						<h3>Lectus Sit</h3>
						<p>Curabitur convallis rutrum erat nec vestibulum. Sed iaculis hendrerit lectus sit amet lobortis vulputate magna finibus molestie tellus.</p>
				  </div>
			  </div>
			  <div class="col-md-4 chrt_grid" style="visibility: visible; -webkit-animation-delay: 0.4s;">
				   <div class="chrty">
						<figure class="icon">
							<span class="glyphicon-icon glyphicon-asterisk" aria-hidden="true"></span>
						</figure>						
						<h3>Rutrum Erat </h3>
						<p>Curabitur convallis rutrum erat nec vestibulum. Sed iaculis hendrerit lectus sit amet lobortis vulputate magna finibus molestie tellus.</p>
				  </div>
			  </div>
			  <div class="col-md-4 chrt_grid" style="visibility: visible; -webkit-animation-delay: 0.4s;">
				   <div class="chrty">
						 <figure class="icon">
							<span class="glyphicon-icon glyphicon-flag" aria-hidden="true"></span>
						</figure>						
						<h3>Sed Iaculis</h3>
						<p>Curabitur convallis rutrum erat nec vestibulum. Sed iaculis hendrerit lectus sit amet lobortis vulputate magna finibus molestie tellus.</p>
				  </div>
			  </div>
			  <div class="clearfix"></div>
		 </div>	
		<div class="banner-grids">
			<div class="col-md-8 banner-grid1">
				
				<h5>Lorem ipsum dolor sit amet, lorem Consec tetuer adipicing it. Praesebul lorem ipsum.S natoque penatibus et gnis dent monteiculu..</h5>
				<p>Lorem ipsum dolor sit amet, lorem Consec tetuer adipicing it. Praesebul lorem ipsum.S natoque penatibus et gnis dent monteiculu. Praesent vesti Cum sociis natoque penatibus et magnis dis parturient montes ascetur ridiculus .</p>
			</div>
			<div class="col-md-4 banner-grid">
				<img src="images/1.jpg" alt=" " class="img-responsive">
			</div>
				<div class="clearfix"></div>
		</div>				 
	 </div>
</div>
<!-- //welcome -->

<!--client-->
	<div class="client">
		<div class="container">
			<h3 class="w3ls_head">Client Says</h3>
			<p class="w3l">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque
				corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</p>
			<!--screen-gallery-->
						<div class="sreen-gallery-cursual">
							 <!-- required-js-files-->
							<link href="css/owl.carousel.css" rel="stylesheet">
							    <script src="js/owl.carousel.js"></script>
							        <script>
							    $(document).ready(function() {
							      $("#owl-demo").owlCarousel({
							        items :1,
							        lazyLoad : true,
							        autoPlay : true,
							        navigation :true,
							        navigationText :  false,
							        pagination : true,
							      });
							    });
							    </script>
								 <!--//required-js-files-->
						       <div id="owl-demo" class="owl-carousel">
							      <div class="item-owl">
					                	<div class="customer-say">
											  <div class="col-md-6 customer-grid">
												<div class="de_testi">
													<div class="quotes"><img src="images/team1.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">Michael </a>, Customer
														</div>
															<div class="clearfix"></div>     
												</div>
											   </div>
											<div class="col-md-6 customer-grid">
											   <div class="de_testi">
													<div class="quotes"><img src="images/team2.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">John </a>, Customer
														</div>
														<div class="clearfix"></div>
												</div>
											</div>
										</div>	
					                </div>
					                 <div class="item-owl">
					                	<div class="customer-say">
											  <div class="col-md-6 customer-grid">
												<div class="de_testi">
													<div class="quotes"><img src="images/team3.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">Michael </a>, Customer
														</div>
															<div class="clearfix"></div>     
												</div>
											   </div>
											<div class="col-md-6 customer-grid">
											   <div class="de_testi">
													<div class="quotes"><img src="images/team4.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">John </a>, Customer
														</div>
														<div class="clearfix"></div>
												</div>
											</div>
										</div>	
					                </div>
					                 <div class="item-owl">
					                	<div class="customer-say">
											  <div class="col-md-6 customer-grid">
												<div class="de_testi">
													<div class="quotes"><img src="images/team4.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">Michael </a>, Customer
														</div>
															<div class="clearfix"></div>     
												</div>
											   </div>
											<div class="col-md-6 customer-grid">
											   <div class="de_testi">
													<div class="quotes"><img src="images/team1.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">John </a>, Customer
														</div>
														<div class="clearfix"></div>
												</div>
											</div>
										</div>	
					                </div>
				              </div>
						</div>
						<!--//screen-gallery-->
		</div>
	</div>	
	<!--//client-->
<!-- what -->
	<div class="what-w3ls">
		<div class="container">
			<h3 class="w3ls_head">Work Process</h3>
			<p class="w3agile">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque
				corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</p>
				<div class="what-grids">
					<div class="col-md-6 what-grid">
						<img src="images/2.jpg" class="img-responsive" alt=""/>
						<div class="what-agile-info">
							<h4>Consectetur</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab aut dignissimos ea est, impedit incidunt, laboriosam consectetur adipisicing elit. Ab aut dignissimos ea est</p>
						</div>
					</div>
					<div class="col-md-6 what-grid1">
						<div class="what-top">
							<div class="what-left">
								<i class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></i>
							</div>
							<div class="what-right">
								<h4>Adipisicing</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab aut dignissimos ea est, impedit incidunt, laboriosam consectetur adipisicing elit. Ab aut dignissimos ea est</p>
							</div>
								<div class="clearfix"></div>
						</div>
						<div class="what-top1">
							<div class="what-left">
								<i class="glyphicon glyphicon-flash" aria-hidden="true"></i>
							</div>
							<div class="what-right">
								<h4>Dignissimos</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab aut dignissimos ea est, impedit incidunt, laboriosam consectetur adipisicing elit. Ab aut dignissimos ea est</p>
							</div>
								<div class="clearfix"></div>
						</div>
						<div class="what-top1">
							<div class="what-left">
								<i class="glyphicon glyphicon-fire" aria-hidden="true"></i>
							</div>
							<div class="what-right">
								<h4>Consectetur</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab aut dignissimos ea est, impedit incidunt, laboriosam consectetur adipisicing elit. Ab aut dignissimos ea est</p>
							</div>
								<div class="clearfix"></div>
						</div>
					</div>
						<div class="clearfix"></div>
				</div>
		</div>
	</div>
<!-- //what -->
<!-- footer -->
<?php include "footer.php"; ?>