<?php
$bannerInfo = 0;
$title = 'Serviços | Portal Trader';
include "header.php";
?>
<!-- //banner -->
<!-- services -->
<!-- services -->
	<div class="services">
		<div class="container">
			<div class="w3_agile_banner_bottom_grid">
				
				<div class="w3_agile_banner_bottom_grid_pos">
					
					<h2 class="w3ls_head">O que Oferecemos</h2>
				</div>
			</div>
			<p class="w3layouts_para">Fusce quis leo in augue ultricies tincidunt a quis mi. Donec at massa nec sem eleifend fermentum.</p>
			<div class="agile_banner_bottom_grids">
				<div class="col-md-3 agile_services_grid">
					<div class="agileits_w3layouts_service_grid">
						<div class="w3_agileits_service_grid">	
							<span></span>
							<i class="fa fa-briefcase" aria-hidden="true"></i>
						</div>
					</div>
					<h4>Placerat nisl</h4>
					<p>Duis ac sodales nulla, sit amet aliquet libero. In auctor sed lectus quis consectetur.</p>
					
				</div>
				<div class="col-md-3 agile_services_grid">
					<div class="agileits_w3layouts_service_grid">
						<div class="w3_agileits_service_grid">	
							<span></span>
							<i class="fa fa-bar-chart" aria-hidden="true"></i>
						</div>
					</div>
					<h4>sodales amet</h4>
					<p>Duis ac sodales nulla, sit amet aliquet libero. In auctor sed lectus quis consectetur.</p>
					
				</div>
				<div class="col-md-3 agile_services_grid">
					<div class="agileits_w3layouts_service_grid">
						<div class="w3_agileits_service_grid">	
							<span></span>
							<i class="fa fa-bullhorn" aria-hidden="true"></i>
						</div>
					</div>
					<h4>Aliquet libero</h4>
					<p>Duis ac sodales nulla, sit amet aliquet libero. In auctor sed lectus quis consectetur.</p>
					
				</div>
				<div class="col-md-3 agile_services_grid">
					<div class="agileits_w3layouts_service_grid">
						<div class="w3_agileits_service_grid">	
							<span></span>
							<i class="fa fa-building-o" aria-hidden="true"></i>
						</div>
					</div>
					<h4>Sed lectus</h4>
					<p>Duis ac sodales nulla, sit amet aliquet libero. In auctor sed lectus quis consectetur.</p>
					
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //services -->
<!-- services-bottom -->
	<div class="services-bottom services">
		<div class="container">
			<h3><i class="fa fa-quote-left" aria-hidden="true"></i>the real mechanism for corporate governance is the active involvement of the owners</h3>
		</div>
	</div>
<!-- //services-bottom -->
<!-- choose -->
	<div class="choose">
		<div class="container">
			<div class="w3_agile_banner_bottom_grid">
				
				<div class="w3_agile_banner_bottom_grid_pos">
					<h3 class="w3ls_head">Why choose us</h3>
				</div>
			</div>
			<p class="w3layouts_para">Fusce quis leo in augue ultricies tincidunt a quis mi. Donec at massa nec sem eleifend fermentum.</p>
			<div class="agile_banner_bottom_grids">
				<div class="col-md-4 agileinfo_choose_left">
					<img src="images/5.jpg" alt=" " class="img-responsive" />
				</div>
				<div class="col-md-8 agileinfo_choose_right">
					<div class="col-md-6 w3l_choose_right_grid">
						<div class="w3_choose_right_grid_main">
							<div class="col-xs-4 agileits_choose_left">
								<div class="w3ls_choose_left_grid hvr-rectangle-out">
									<i class="fa fa-building-o" aria-hidden="true"></i>
								</div>
							</div>
							<div class="col-xs-8 agileits_choose_right">
								<h4>turpis tincidunt</h4>
								<p>Duis lobortis in ex sed cursus. Etiam ac risus at ex blandit placerat id ac augue.</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3_choose_right_grid_main">
							<div class="col-xs-4 agileits_choose_left">
								<div class="w3ls_choose_left_grid hvr-rectangle-out">
									<i class="fa fa-bullhorn" aria-hidden="true"></i>
								</div>
							</div>
							<div class="col-xs-8 agileits_choose_right">
								<h4>Etiam ac risus</h4>
								<p>Duis lobortis in ex sed cursus. Etiam ac risus at ex blandit placerat id ac augue.</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="col-md-6 w3l_choose_right_grid">
						<div class="w3_choose_right_grid_main">
							<div class="col-xs-4 agileits_choose_left">
								<div class="w3ls_choose_left_grid hvr-rectangle-out">
									<i class="fa fa-bar-chart" aria-hidden="true"></i>
								</div>
							</div>
							<div class="col-xs-8 agileits_choose_right">
								<h4>lobortis in ex </h4>
								<p>Duis lobortis in ex sed cursus. Etiam ac risus at ex blandit placerat id ac augue.</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3_choose_right_grid_main">
							<div class="col-xs-4 agileits_choose_left">
								<div class="w3ls_choose_left_grid hvr-rectangle-out">
									<i class="fa fa-briefcase" aria-hidden="true"></i>
								</div>
							</div>
							<div class="col-xs-8 agileits_choose_right">
								<h4>placerat augue </h4>
								<p>Duis lobortis in ex sed cursus. Etiam ac risus at ex blandit placerat id ac augue.</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //choose -->
<!-- //services -->

<?php include "footer.php"; ?>