<?php
$bannerInfo = 0;
$title = 'Quem Somos | Portal Trader';
include "header.php";
?>
<!-- //banner -->
<!-- About -->
	<div class="courses">
		<div class="container">
			<h2 class="w3ls_head">Conheça-nos</h2>
			<p class="w3layouts_para">Fusce quis leo in augue ultricies tincidunt a quis mi. Donec at massa nec sem eleifend fermentum.</p>
			<div class="agileits_w3layouts_team_grids w3ls_courses_grids">
				<div class="col-md-6 w3ls_banner_bottom_left w3ls_courses_left">
					<div class="w3ls_courses_left_grids">
						<div class="w3ls_courses_left_grid">
							<h3><i class="fa fa-pencil-square-o" aria-hidden="true"></i>pulvinar neque pharetra eget</h3>
							<p>Pellentesque convallis diam consequat magna vulputate malesuada.
								Cras a ornare elit.Cras a ornare elit. Nulla viverra pharetra sem, eget pulvinar  Nulla viverra pharetra sem, eget pulvinar neque pharetra ac.</p>
						</div>
						<div class="w3ls_courses_left_grid">
							<h3><i class="fa fa-pencil-square-o" aria-hidden="true"></i>consequat magna vulputate</h3>
							<p>Pellentesque convallis diam consequat magna vulputate malesuada.
								Cras a ornare elit.Cras a ornare elit. Nulla viverra pharetra sem, eget pulvinar  Nulla viverra pharetra sem, eget pulvinar neque pharetra ac.</p>
						</div>

					</div>
				</div>
				<div class="col-md-6 agileits_courses_right">
					<img src="images/2.jpg" alt=" " class="img-responsive">
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- /About -->
<!--client-->
	<div class="client">
		<div class="container">
			<h3 class="w3ls_head">Client Says</h3>
			<p class="w3l">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque
				corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</p>
			<!--screen-gallery-->
						<div class="sreen-gallery-cursual">
							 <!-- required-js-files-->
							<link href="css/owl.carousel.css" rel="stylesheet">
							    <script src="js/owl.carousel.js"></script>
							        <script>
							    $(document).ready(function() {
							      $("#owl-demo").owlCarousel({
							        items :1,
							        lazyLoad : true,
							        autoPlay : true,
							        navigation :true,
							        navigationText :  false,
							        pagination : true,
							      });
							    });
							    </script>
								 <!--//required-js-files-->
						       <div id="owl-demo" class="owl-carousel">
							      <div class="item-owl">
					                	<div class="customer-say">
											  <div class="col-md-6 customer-grid">
												<div class="de_testi">
													<div class="quotes"><img src="images/team1.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">Michael </a>, Customer
														</div>
															<div class="clearfix"></div>
												</div>
											   </div>
											<div class="col-md-6 customer-grid">
											   <div class="de_testi">
													<div class="quotes"><img src="images/team2.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">John </a>, Customer
														</div>
														<div class="clearfix"></div>
												</div>
											</div>
										</div>
					                </div>
					                 <div class="item-owl">
					                	<div class="customer-say">
											  <div class="col-md-6 customer-grid">
												<div class="de_testi">
													<div class="quotes"><img src="images/team3.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">Michael </a>, Customer
														</div>
															<div class="clearfix"></div>
												</div>
											   </div>
											<div class="col-md-6 customer-grid">
											   <div class="de_testi">
													<div class="quotes"><img src="images/team4.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">John </a>, Customer
														</div>
														<div class="clearfix"></div>
												</div>
											</div>
										</div>
					                </div>
					                 <div class="item-owl">
					                	<div class="customer-say">
											  <div class="col-md-6 customer-grid">
												<div class="de_testi">
													<div class="quotes"><img src="images/team4.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">Michael </a>, Customer
														</div>
															<div class="clearfix"></div>
												</div>
											   </div>
											<div class="col-md-6 customer-grid">
											   <div class="de_testi">
													<div class="quotes"><img src="images/team1.jpg" alt=""></div>
														<div class="de_testi_by">
															<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
															<a href="#">John </a>, Customer
														</div>
														<div class="clearfix"></div>
												</div>
											</div>
										</div>
					                </div>
				              </div>
						</div>
						<!--//screen-gallery-->
		</div>
	</div>
	<!--//client-->
<!-- team -->
	<div class="team">
		<div class="container">
			<h3 class="w3ls_head">Our Team</h3>
			<p class="w3layouts_para">Fusce quis leo in augue ultricies tincidunt a quis mi. Donec at massa nec sem eleifend fermentum.</p>
			<div class="w3_services_grids">
				<div class="col-md-3 w3ls_team_grid">
					<div class="w3ls_team_grid1 hover15">
						<figure>
							<img src="images/team3.jpg" alt=" " class="img-responsive" />
						</figure>
						<div class="w3ls_team_grid1_pos">
							<ul class="social-icons">
								<li><a href="#" class="icon icon-border facebook"></a></li>
								<li><a href="#" class="icon icon-border twitter"></a></li>
								<li><a href="#" class="icon icon-border instagram"></a></li>
							</ul>
						</div>
					</div>
					<h4>JOE</h4>
					<p>The printing</p>
				</div>
				<div class="col-md-3 w3ls_team_grid">
					<div class="w3ls_team_grid1 hover15">
						<figure>
							<img src="images/team4.jpg" alt=" " class="img-responsive" />
						</figure>
						<div class="w3ls_team_grid1_pos">
							<ul class="social-icons">
								<li><a href="#" class="icon icon-border twitter"></a></li>
								<li><a href="#" class="icon icon-border instagram"></a></li>
								<li><a href="#" class="icon icon-border facebook"></a></li>
							</ul>
						</div>
					</div>
					<h4>ADAM</h4>
					<p>Lorem Ipsum</p>
				</div>
				<div class="col-md-3 w3ls_team_grid">
					<div class="w3ls_team_grid1 hover15">
						<figure>
							<img src="images/team2.jpg" alt=" " class="img-responsive" />
						</figure>
						<div class="w3ls_team_grid1_pos">
							<ul class="social-icons">
								<li><a href="#" class="icon icon-border instagram"></a></li>
								<li><a href="#" class="icon icon-border facebook"></a></li>
								<li><a href="#" class="icon icon-border twitter"></a></li>
							</ul>
						</div>
					</div>
					<h4>JACK</h4>
					<p>The printing</p>
				</div>
				<div class="col-md-3 w3ls_team_grid">
					<div class="w3ls_team_grid1 hover15">
						<figure>
							<img src="images/team1.jpg" alt=" " class="img-responsive" />
						</figure>
						<div class="w3ls_team_grid1_pos">
							<ul class="social-icons">
								<li><a href="#" class="icon icon-border pinterest"></a></li>
								<li><a href="#" class="icon icon-border twitter"></a></li>
								<li><a href="#" class="icon icon-border instagram"></a></li>
							</ul>
						</div>
					</div>
					<h4>LANA</h4>
					<p>Lorem Ipsum</p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //team -->
<!-- footer -->
<?php include "footer.php"; ?>